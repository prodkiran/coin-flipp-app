import CoinFlip from "@/components/CoinFlip";

const Index = () => {
  return <CoinFlip />;
};

export default Index;
